# One-bar NQ 30-minute research package

This package records an exploratory one-bar breakout candidate. It is not approval to trade. The underlying prices are Dukascopy USATECH.IDX/USD BID data. They are a CFD/index proxy, not verified CME E-mini Nasdaq-100 futures data. The one-contract, USD 20 per point mapping is illustrative.

## Frozen rule description

Use the high and low of the prior 50 complete 30-minute bars. Submit one buy stop at the high and one sell stop at the low. Cancel the other entry after the first fill. Use one illustrative contract in either direction. Set a nominal USD 1,000 protective stop. Exit at the opening print of the immediately following 30-minute bar. Allow at most two entries per Chicago session day. Use extended hours. Add no filters.

## Evidence status

An earlier retrospective proxy run reported positive costs-adjusted historical values. The remediation audit found delayed exits, unresolved OCO behavior, and intraminute ambiguities. A later annual native-engine replay completed, but its source remains a BID-only CFD proxy and its OHLC event-order limits remain. Do not treat the earlier result as corrected performance or as evidence of CME execution edge.

The practical native-engine yearly run is marked `completed` in its canonical ledger at this packaging snapshot. This package includes completed per-year outputs for 2013–2026, where both zero-cost and full-tick trials have completed summaries and ledgers. The 2026 costed annual result is negative (238 trades, -$14,166.96). Annual outputs still retain modeled OHLC ambiguities, and the native broker does not provide atomic OCO. This result does not resolve those execution limits or approve the strategy. Consult `STATUS.md` and the copied trial ledger for exact results.

## Contents and reproduction

- `src/` and `tests/` are snapshots of the task-owned root scripts and tests. They retain their original workspace paths and dependencies.
- `backtests/` contains copied completed run artifacts. Superseded duplicate-logic directories and transient logs are omitted. Their source run paths are recorded in `provenance/manifest.json`.
- `data/data_manifest.json` identifies the canonical external source. The raw multi-million-row Parquet store is not duplicated.
- Run `python promote/one_bar_nq_30m/scripts/verify_package.py` from the repository root to validate required files, YAML, and SHA256 values.
- After the yearly job has completed, run `python promote/one_bar_nq_30m/scripts/refresh_completed_runs.py` from the repository root to copy only years with completed summaries and both completed trial artifacts. This script does not write to source runs.
- To reproduce source backtests, use the copied runner with the source workspace and its original dependencies, then compare outputs with the frozen specs and manifests. The external raw dataset must be present at its canonical path and pass the frozen hashes. A package copy alone does not contain that dataset.

## Research limitations

The native broker cannot enforce atomic OCO. Minute OHLC cannot establish the order of events inside a minute. Stop gaps can exceed the nominal USD 1,000 risk. The input is BID-only and does not provide verified ASK quotes. The cost assumptions are illustrative. The historical trial set is retrospective and incomplete for multiple-testing correction. No protected data after 2026-07-14 was used by the historical strategy run.

See `audits/` for the review reports. The original run folders and source files remain in place.
# Retrospective tearsheet

The annual practical replay summary is available in [`reports/one_bar_nq_tearsheet_2013_2026.md`](reports/one_bar_nq_tearsheet_2013_2026.md), with the PNG, machine-readable metrics, daily realized cash-flow series, and monthly PnL in the same directory. Regenerate it with:

```bash
python promote/one_bar_nq_30m/scripts/generate_tearsheet.py
```

The report uses completed evaluation-trade ledgers only. It does not rerun the backtest. It is a retrospective report of a BID-only Dukascopy index/CFD proxy, not verified CME NQ performance. It does not change the `NOT_APPROVED` status. Its cumulative realized cash-flow series does not mark open positions and does not represent native mark-to-market equity.

## 2026 regime attribution

See [the historical 2026 regime report](reports/regime_2026/README.md) and its [machine-readable metrics](reports/regime_2026/metrics.json). This is an accounting and conditional-attribution review. It does not change the fixed strategy or its `NOT_APPROVED` status.
